<p>
    This is a test, an email test.
</p>
<p>
    The variable <code>$testVar</code> contains the value:
</p>
<ul>
    <li><strong>{{ $testVar }}</strong></li>
</ul>
<hr>
<p>
    That is all.
</p>